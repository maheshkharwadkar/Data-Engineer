package common

case class InputConfig(env : String, targetDB : String)
