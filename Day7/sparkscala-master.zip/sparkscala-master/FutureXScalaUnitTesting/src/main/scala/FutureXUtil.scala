object FutureXUtil {
  def divideVars(a : Int,b : Int ): Int = {
  a/b
  }
}
