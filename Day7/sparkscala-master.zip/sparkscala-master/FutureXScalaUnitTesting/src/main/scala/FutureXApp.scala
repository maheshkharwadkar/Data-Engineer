object FutureXApp {
  def main(args: Array[String]): Unit = {
    println("FutureX project")
    println("Dividing "+ FutureXUtil.divideVars(30,10))
  }
}
