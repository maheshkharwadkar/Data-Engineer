package common

import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

abstract class FutureXBase extends AnyFlatSpec with Matchers  {

}
