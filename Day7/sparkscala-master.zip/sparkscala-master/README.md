Only Udemy course which teaches you how to code and test Spark Scala in a real world project . Also learn Structured Streaming

https://www.udemy.com/course/spark-scala-coding-best-practices-data-pipeline/?referralCode=DBA026944F73C2D356CF

Watch it for free on Skillshare

Spark Scala

https://skl.sh/2WPsiRe

Structured Streaming

https://skl.sh/3lwA7qp
